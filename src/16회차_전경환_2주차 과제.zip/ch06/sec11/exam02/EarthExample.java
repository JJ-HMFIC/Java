package ch06.sec11.exam02;

public class EarthExample {
    public static void main(String[] args) {
        System.out.println("지구의 반지름 : " + Earth.EARTH_RADIUS);
        System.out.println("지구의 표면적 : " + Earth.EARTH_SURFACE_AREA);
    }

}
