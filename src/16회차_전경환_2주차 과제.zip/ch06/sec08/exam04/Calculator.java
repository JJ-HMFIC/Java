package ch06.sec08.exam04;

public class Calculator {

    public double areaRectangle(double i) {
        return  i * i;
    }

    public double areaRectangle(double i, double j) {
        return  i * j;
    }
}
