package ch06.sec07.exam01;


public class Car {
    String name;
    String color;
    int speed;

    public Car(String name, String color, int speed) {
        this.name = name;
        this.color = color;
        this.speed = speed;
    }
}
