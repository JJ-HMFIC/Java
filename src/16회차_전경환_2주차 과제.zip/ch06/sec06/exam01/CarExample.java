package ch06.sec06.exam01;

public class CarExample {
    public static void main(String[] args) {
        Car car1 = new Car();
        System.out.println(car1.model);
        System.out.println(car1.start);
        System.out.println(car1.speed);
    }
}
